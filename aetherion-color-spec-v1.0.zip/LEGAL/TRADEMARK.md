# Trademark Notice – Aetherion™

“Aetherion” is a trademark of **Velkrune™**. The numeric color definitions and accompanying technical documentation are released under CC0, but the **name** itself is reserved. You may reference the color numerically without using the trademarked name. To use the Aetherion™ name in products, packaging, or marketing, obtain written permission from Velkrune™.
